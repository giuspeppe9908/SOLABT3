#ifndef _FUNCTIONS_H_
#define _FUNCTIONS_H_
FILE *fp;
extern const int sources_MAX, n_k, holes;
extern const int griglia_def[200][200];
#define MAXRIC 100
/*Colori differenti per HOLES, TAXI, SO_SOURCES e TESTO*/
#define RED   "\x1B[31m" /*HOLES COLOR*/
#define YEL   "\x1B[33m" /*TAXI COLOR*/
#define BLU   "\x1B[34m" /*SO_SOURCES COLOR*/
#define WHT   "\x1B[37m"
#define MAG   "\x1B[35m" /*RICHIESTE COLOR*/ 
/*structures*/
/*struct source*/
struct source{
   int rp;/*riga partenza*/
   int rd;/*riga destinazione*/
   int cp;/*colonna partenza*/
   int cd;/*colonna destinazione*/
   int pid;/*PID Processo SOURCE*/
   int richieste[MAXRIC];/*array richieste.*/
}s;
struct taxi{
    int my_pid;//pid taxi 
    int x_pos;//posizione in riga i
    int y_pos;//posizione in colonna j
    //array che contiene taxi
    int t[];
}tx;

struct matrix{
   int app[200][200];
}m;
/*metodi*/
void drawcar(int);  /*Stampa della macchina*/
void printline(char *, int);  /*Stampa delle linee per il Taxi drawcar*/
void car_on_screen();  /*Stampa effettiva del taxi*/
/*funzioni per il file*/
void LetturaImpostazioni(FILE *); /*Sola lettura delle impostazioni per la stampa*/
void LetturaInteridaFile(FILE *); /*Lettura degli interi dal file delle impo.*/
/*funzioni della griglia*/
void Stampa(int r, int c, int griglia_def[r][c]);
void StampaSources(int N, struct source s);
void InserimentoHoles(int r, int c, int holes, int griglia_def[r][c]);
void InserimentoTaxi(int n_k, int r, int c, int griglia_def[r][c]);
void InserimentoRichiesta(int r, int c, struct source s, int griglia_def[r][c]);
void Sources(int r, int c, int griglia_def[r][c], int sources);
void CopiaStructMat(int r, int c, struct source s, int griglia_def[r][c]);
void StampaStruct(int r, int c, struct source s);
#endif
