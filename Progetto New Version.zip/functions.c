#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <time.h>
#include <sys/wait.h>
#include <sys/shm.h>
#include <errno.h>
#include <string.h>
#include <sys/ipc.h>/*usata per code messaggi*/
#include <sys/msg.h>/*usata per code messaggi*/
#include <sys/types.h>
#include <semaphore.h>
#include <pthread.h>
#include "functions.h"
#define CLEAR "clear"
char array[12];/*righe FILE fp*/
char *res; /*per contenere la singola riga del file*/
#define MAX 10000
#define MAXRIC 100
//struct taxi tx;
struct source s;
/*dichiarazione di 2 semafori*/
sem_t s1, s2;
/*pthread*/
pthread_t tid[2];  
pthread_mutex_t lock;
/*struct source*/ 
void Sources(int r, int c, int shm_id, int sources){
     int i,req_i, pid = getppid(), child_pid;
     int stato = 0;
     printf(WHT "N Sources : %d", sources);
     printf(WHT "\n Processo source [PID] : %d\n", pid);//processo padre sources
     printf(WHT "|| PID SOURCE || CELLA PARTENZA || CELLA ARRIVO || TOT. RICHIESTE ||\n");
     for(i = 0, req_i=0; i < sources && req_i < MAXRIC; i++, req_i++){
        pid = fork();
        child_pid = getpid();   
        //genero ogni cella di partenza per ogni processo source.
        int row = rand() % r;
        int col = rand() % c;
        //caso del figlio
        if(pid == 0 && s.richieste[req_i] == 0){
           srand(getpid());
           int **griglia_def = shmat(shm_id , NULL , 0);//shmat del figlio
           //Ho generato la riga e la colonna di partenza. Genero quelle di arrivo.
           int row2 = rand() % r;
           int col2 = rand() % c;
           if(row2 != row && col2 != col){
             //inserisco i dati nella struct source
             s.rp = row;
             s.rd = row2;
             s.cp = col;
             s.cd = col2;
             s.pid = child_pid;//pid del processo source.
             s.richieste[req_i] = rand() % MAXRIC + 1;//per non avere ripetizioni
             printf("--------------------------\n");
             printf("|PID SOURCE : %d|\n", s.pid);
             printf("| P -> [%d , %d]|\n", s.rp, s.cp);
             printf("| A -> [%d , %d]|\n", s.rd, s.cd);
             printf("| Numero RICHIESTE : %d|\n", s.richieste[req_i]);
             printf("--------------------------\n");
             //sem_wait(&s1);//trattengo la risorsa.
             pthread_mutex_lock(&lock);
             griglia_def[c * row + col] = s.richieste[req_i];
             printf("I hold this position...\n");
             //sem_post(&s2);//sblocco s2.
             pthread_mutex_unlock(&lock);
           }
          printf("Inserimento richieste riuscito con successo!\n"); 
          exit(0);//exit figlio 
         }
       }
}

void InserimentoHoles(int r, int c, int holes, int** griglia_def){
     srand(time(NULL));
     printf(WHT "Inserimento Holes...\n");
     int i, value_holes = -1;
     for(i = 0; i < holes; i++){
        //genero una coordinata [r,c]
        int new_row = rand() % r;
        int new_col = rand() % c;
        griglia_def[(new_row * c) + new_col] = griglia_def[(new_row * c) + new_col-1];
        if(griglia_def[(new_row * c) + new_col] == -2){
           griglia_def[(new_row*c) + new_col] = value_holes;
           i = i - 1;
        }
        //controllo se la centrale (nuova) è accerchiata da zeri.
        if(griglia_def[new_row-1 * c + new_col-1] == -1 ||
           griglia_def[new_row-1 * c + new_col] == -1 ||
           griglia_def[new_row-1 * c + new_col+1] == -1 ||
           griglia_def[new_row * c + new_col-1] == -1 ||
           griglia_def[new_row * c + new_col+1] == -1 ||
           griglia_def[new_row+1 * c + new_col-1] == -1 ||
           griglia_def[new_row+1 * c + new_col] == -1 ||
           griglia_def[new_row+1 * c + new_col+1] == -1){
             //Se la troviamo piena decrementiamo la i
             *(*(griglia_def+new_row) + new_col) = 0;
             i = i - 1;
           }

     }
}
/*void InserimentoHoles2(int r, int c, int holes, int griglia_def[r][c]){
     srand(time(NULL));
     printf(WHT "Inserimento Holes...\n");
     int i, value_holes = -1;
     for(i = 0; i < holes; i++){
        
        int new_row = rand() % r;
        int new_col = rand() % c;
        griglia_def[new_row][new_col] = griglia_def[new_row][new_col]-1;
        if(griglia_def[new_row][new_col] == -2){
           griglia_def[new_row][new_col] = value_holes;
           i = i - 1;
        }
        //controllo se la centrale (nuova) è accerchiata da zeri.
        if(griglia_def[new_row-1][new_col-1] == value_holes ||
           griglia_def[new_row-1][new_col] == value_holes ||
           griglia_def[new_row-1][new_col+1] == value_holes ||
           griglia_def[new_row][new_col-1] == value_holes ||
           griglia_def[new_row][new_col+1] == value_holes ||
           griglia_def[new_row+1][new_col-1] == value_holes ||
           griglia_def[new_row+1][new_col] == value_holes ||
           griglia_def[new_row+1][new_col+1] == value_holes){
             //Se la troviamo piena decrementiamo la i
             griglia_def[new_row][new_col] = 0;
             i = i - 1;
           }

     }
}*/

void InserimentoTaxi(int num_kids, int r, int c, int** griglia_def){
    int i = 0, pid = getppid();
    printf(WHT "Taxi generati : %d\n", num_kids);
    //nel campo t[] del taxi inserisco i num_kids cioé i taxi
    tx.t[num_kids];
    //carico i pid dei figli nell'array
    for(i=0; i < num_kids; i++){
      pid = fork();
      tx.my_pid = getpid();
      if(pid == 0){
       srand(getpid());
       tx.t[i] = tx.my_pid;//carico fino a quando i < num_kids
       //prova di stampa, decommentare per fare un test
       //printf("PID figlio n° %d ~~> %d\n",i , tx.t[i]);
       exit(0);
      }
      i++;
    }
    srand((unsigned)time(NULL));
    //inserisco taxi e carico xpos e ypos per poi visualizzarli nella griglia.
    i=0;
    while(i < num_kids){
       tx.x_pos = rand()%r;
       tx.y_pos = rand()%c;
       if(griglia_def[tx.x_pos * c + tx.y_pos] >= 0)
         griglia_def[tx.x_pos * c + tx.y_pos] = griglia_def[tx.x_pos * c + tx.y_pos]+1;
       if(griglia_def[tx.x_pos * c + tx.y_pos] == -1){
          i--;
       }
       i++;
    }
}

void Stampa(int r, int c, int** griglia_def){
    printf(WHT "-----------------------------------------------------\n");
    int i, j, req_i=0;
    for(i = 0; i < r; i++){
            printf("\t");
	    for(j = 0; j < c; j++){
		    if(griglia_def[i*c+j] == -1){
		    printf(RED " %d \t", griglia_def[i*c+j]);
		    }
		    else if(griglia_def[i*c+j] == 0){
		     printf(BLU " %d \t", griglia_def[i*c+j]);
		    }
		    else if(griglia_def[i*c+j] > 0 && griglia_def[i * c + j] <= 8){
		       printf(YEL " %d \t", griglia_def[i*c+j]);
		       }
		    else
		       printf(GRE " %d \t", griglia_def[i*c+j]);
		}
		printf("\n");
    }
    printf(WHT "-----------------------------------------------------\n");
}

/*void StampaMat(int r, int c, int griglia_def[r][c]){
    printf(WHT "-----------------------------------------------------\n");
    int i, j, req_i=0;
    for(i = 0; i < r; i++){
            printf("\t");
	    for(j = 0; j < c; j++){
		    if(griglia_def[i][j] == -1){
		    printf(RED " %d \t", griglia_def[i][j]);
		    }
		    else if(griglia_def[i][j] == 0){
		     printf(BLU " %d \t", griglia_def[i][j]);
		    }
		    else if(griglia_def[i][j] > 0){
		       printf(GRE " %d \t", griglia_def[i][j]);
		       }
		    else
		       printf(YEL " %d \t", griglia_def[i][j]);
		}
		printf("\n");
    }
    printf(WHT "-----------------------------------------------------\n");
}*/
//  Stampa source + griglia
void StampaSources(int N, struct source s){
    printf(WHT "-----------------------------------------------------\n");
    for(int r=0; r < N; r++){
      printf(GRE "[PID] : %d | Riga Partenza : %d | Colonna Partenza : %d | Richieste : %d\n", s.pid, s.rp, s.cp, s.richieste[r]);
    }
    printf(WHT "-----------------------------------------------------\n");
}
/*graphic car function*/
void printline(char *line, int no)
{
   int i;
   for(i = 0; i < no; i++)
      printf(" ");
    printf("%s\n", line);
}
void drawcar(int no_of_spaces){
   char *line1 = "      .-[TAXI]--.";
   char *line2 = " ____/_____|___ \\___";
   char *line3 = " O   _   - |   _    ,*";
   char *line4 = " '--(_)-------(_)--'";
   char *line5 = "   The TaxiCab Game ";
 printline(line1, no_of_spaces);
 printline(line2, no_of_spaces);
 printline(line3, no_of_spaces);
 printline(line4, no_of_spaces);
 printline(line5, no_of_spaces);
}
void car_on_screen(){
  int count;
  int status = 3;
  printf("\n");
  for(count = 0; count < status; count++){
		 sleep(1);
		 system("clear");
		 drawcar(count);
  }
}

void LetturaImpostazioni(FILE *fp){
fp = fopen("default.txt", "r");
    if(fp == NULL){
       printf("Impossibile aprire il FILE.");
    }
         printf(":: Impostazioni di default ::\n");
           while(1){
              res = fgets(array,12,fp);
              if(res == NULL)
                break;
                   printf("%s", array);
		   }
    /*chiudo file*/
    fclose(fp);
}

void LetturaInteridaFile(FILE *fp){   /*prelevo i numeri dal file e li metto*/
                                      /*dentro ad un array e li stampo.*/
    fp = fopen("default.txt", "r");
    /*vettore per numeri*/
    int maxcount = 24;
    int intCount = 0;
    int intArray[maxcount];
    char line[1000];
    while (fp && fgets(line,sizeof(line),fp)) {
        char* token = strtok(line, " ");
        while (token) {
            int num;
            if (sscanf(token, "%d", &num) == 1) { /*sscanf usata per capire SE è stato copiato il numero.*/
                if (intCount < maxcount){
                    intArray[intCount++] = num;
                }
            }
            token = strtok(NULL, " ");
        }
    }
    /*Stampa dei soli interi*/
    printf("Numeri presenti nel file: \n");
    int i,j;
    for(i = 0; i<maxcount/2; i++) {
           printf(" %d - ",intArray[i]);
    }
    printf("\n");
    for(j=(maxcount/2)+1; j<maxcount; j++) {
           printf(" %d - ",intArray[j]);
    }
    printf("\n");
}
