#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <time.h>
#include <sys/shm.h>
#include <sys/wait.h>
#include <errno.h>
#include <string.h>
/*includo la libreria functions.h*/
#include "functions.h"
#define CLEAR "clear"
/*Variabili globali*/
FILE * fp; /*nome del file a puntatore*/
int mat_var[12][2];/*matrice variabili del file*/
/*struct source s*/
//struct source s;
//struct matrix m;//matrice di appoggio a griglia_def
/*Prototipi di funzioni*/
int main(){
    car_on_screen();   /*metodo iniziale visualizzazione taxi*/
    sleep(1);
    system(CLEAR);
    LetturaImpostazioni(fp);
    /*lettura dei soli numeri interi da File e li metto nell'array intArray*/
    fp = fopen("default.txt", "r");
    int maxcount = 24;
    int intCount = 0;
    int intArray[maxcount];
    char line[1000];
    while (fp && fgets(line,sizeof(line),fp)){
      char* token = strtok(line, " ");
      while (token) {
          int num;
          if (sscanf(token, "%d", &num) == 1) { /*sscanf usata per capire SE è stato copiato il numero.*/
            if (intCount < maxcount){
                intArray[intCount++] = num;
            }
          }
          token = strtok(NULL, " ");
      }
    }
/*Allocazione della matrice delle variabili.*/
    printf("\n Numeri presenti nel file: \n");
    int i;
    int j;
    /*Copio in mat_var i valori di intArray*/
    for(i=0; i < maxcount; i=i+2){
      mat_var[j][0]=intArray[i];
      j++;
    }
    j=0;
    for(i=1; i < maxcount; i=i+2){
      mat_var[j][1]=intArray[i];
      j++;
    }

    for(i=0; i< 12; i++){
      for(j=0; j< 2; j++){
        printf("%d ", mat_var[i][j]);
      }
      printf("\n");
    }
/*Inizializzazione Variabili*/
    int SO_WIDTH = mat_var[0][1];
    int SO_HEIGHT = mat_var[1][1];
    int SO_HOLES = mat_var[2][1];
    int SO_TOP_CELLS = mat_var[3][1];
    int SO_SOURCES = mat_var[4][1];
    int SO_CAP_MIN = mat_var[5][1];
    int SO_CAP_MAX = mat_var[6][1];
    int SO_TAXI = mat_var[7][1];
    int SO_TIMESEC_MIN = mat_var[8][1];
    int SO_TIMESEC_MAX = mat_var[9][1];
    int SO_TIMEOUT = mat_var[10][1];
    int SO_DURATION = mat_var[11][1];
    /*shared memory*/
    int** griglia_def;
    //int griglia_app[SO_WIDTH][SO_HEIGHT];
    //memset(griglia_app, 0, sizeof griglia_app);
    memset(griglia_def, 0, sizeof(SO_WIDTH*SO_HEIGHT));
    int shm_id = shmget(IPC_PRIVATE, sizeof(int**)*(SO_WIDTH*SO_HEIGHT), 0600) ;
    if(shm_id < 0) printf("Error!\n");
    griglia_def = shmat(shm_id,NULL,0);//shmat del padre
    system(CLEAR);
    Stampa(SO_WIDTH, SO_HEIGHT, griglia_def);
    /*Generazione randomica N SO_HOLES*/
    //StampaMat(SO_WIDTH, SO_HEIGHT, griglia_app);
    int holes = SO_HOLES; 
    printf(WHT "Holes generati da immettere nella griglia : %d\n", holes);
    /*Funzione che RANDOMICAMENTE inserisce questi holes nella griglia (chiamata griglia_def)*/
    InserimentoHoles(SO_WIDTH, SO_HEIGHT, holes, griglia_def);
    //InserimentoHoles2(SO_WIDTH, SO_HEIGHT, holes, griglia_app);
    /*Stampa griglia "aggiornata"*/
    //StampaMat(SO_WIDTH, SO_HEIGHT, griglia_app);
    Stampa(SO_WIDTH, SO_HEIGHT, griglia_def);
    /* Inserimento taxi */
    InserimentoTaxi(SO_TAXI, SO_WIDTH, SO_HEIGHT, griglia_def);
    /*Stampa griglia "aggiornata"*/
    Stampa(SO_WIDTH, SO_HEIGHT, griglia_def);
    /*Richiesta Servizio Taxi*/
    int sources = SO_SOURCES;
    //s = 
    Sources(SO_WIDTH, SO_HEIGHT, shm_id, sources);
    sleep(2);
    //StampaSources(sources, s);
    Stampa(SO_WIDTH, SO_HEIGHT, griglia_def);
    return 0;
}
